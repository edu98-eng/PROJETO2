#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cstdlib>
#include "figurageometrica.h"
#include "Escultor3D.h"
#include "putVoxel.h"
#include "cutVoxel.h"
#include "cutBox.h"
#include "putBox.h"
#include "putSphere.h"
#include "cutSphere.h"
#include "putEllipsoid.h"
#include "cutEllipsoid.h"

using namespace std;

int main()
{
    vector<FiguraGeometrica*> figura;
    cout<<"O projeto foi executado!"<<endl;
    return 0;
}
