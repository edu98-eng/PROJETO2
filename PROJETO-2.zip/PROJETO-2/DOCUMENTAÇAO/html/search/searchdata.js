var indexSectionsWithContent =
{
  0: "cdfmp",
  1: "cfp",
  2: "cfmp",
  3: "cdfmp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções"
};

