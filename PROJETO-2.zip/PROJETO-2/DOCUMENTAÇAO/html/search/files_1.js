var searchData=
[
  ['figurageometrica_2ecpp_47',['figurageometrica.cpp',['../figurageometrica_8cpp.html',1,'']]],
  ['figurageometrica_2eh_48',['figurageometrica.h',['../figurageometrica_8h.html',1,'']]]
];
