var searchData=
[
  ['figurageometrica_34',['FiguraGeometrica',['../class_figura_geometrica.html',1,'']]]
];
