#include "figurageometrica.h"

FiguraGeometrica::FiguraGeometrica()
{

}
